describe("Teste inicial do Jest", () => {
    it("funciona corretamente", () => {
        expect(2 + 2).toBe(4);
    });
});
